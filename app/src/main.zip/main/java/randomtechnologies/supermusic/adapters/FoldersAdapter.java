package randomtechnologies.supermusic.adapters;

/**
 * Created by HP on 09-08-2017.
 */
public class FoldersAdapter {
}
