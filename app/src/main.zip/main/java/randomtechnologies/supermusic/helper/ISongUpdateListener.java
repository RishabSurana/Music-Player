package randomtechnologies.supermusic.helper;

/**
 * Created by HP on 20-08-2017.
 */
public interface ISongUpdateListener {

    void songUpdatedListener();
}
