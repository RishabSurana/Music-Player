package randomtechnologies.supermusic.fragments;


import android.support.v4.app.Fragment;

/**
 * Created by HP on 16-08-2017.
 */
public class BaseFragment extends Fragment {
}
