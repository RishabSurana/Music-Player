package randomtechnologies.supermusic.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by HP on 16-08-2017.
 */
public class NotificationActionReceivers extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

    }
}
